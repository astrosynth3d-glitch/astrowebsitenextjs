"use client";
import { motion } from 'framer-motion';
import './Style/home.css';

export default function HomePage() {
  return (
    /* Cleaned wrapper: Removed background colors and overflow constraints */
    <div className="relative min-h-screen text-white font-sans antialiased flex flex-col items-center justify-center z-0">
      
      {/* REMOVED: Liquid Ambient Backgrounds 
          REMOVED: Grid Overlay for Texture 
      */}

      {/* Hero Section */}
      <main className="relative z-10 flex flex-col items-center justify-center text-center px-4 w-full">
        
        {/* Liquid Glass Badge */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="premium-liquid-badge px-6 py-3 rounded-full mb-10 flex items-center gap-3 cursor-pointer group"
          role="status"
          aria-label="Status: Recording My Journey"
        >
          <div className="relative flex items-center justify-center w-2 h-2">
            <span className="absolute inline-flex w-full h-full rounded-full bg-cyan-400 opacity-60 animate-ping group-hover:opacity-100 transition-opacity duration-500"></span>
            <span className="relative inline-flex rounded-full w-1.5 h-1.5 bg-cyan-300 shadow-[0_0_8px_rgba(34,211,238,0.8)]"></span>
          </div>
          
          <span className="text-xs font-black tracking-[0.3em] uppercase text-cyan-50 group-hover:text-cyan-300 transition-colors duration-300">
            Recording My Journey
          </span>
        </motion.div>

        {/* Title Section */}
        <motion.h1 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="text-6xl sm:text-7xl md:text-9xl font-black mb-8 italic uppercase leading-[0.85] tracking-tighter cursor-default"
        >
          <span className="block text-white drop-shadow-2xl transition-transform hover:scale-[1.02] duration-700 ease-out">
            Astrosynth
          </span>
          <span className="block mt-4 hollow-text select-none transition-all duration-700 hover:drop-shadow-[0_0_25px_rgba(34,211,238,0.4)]">
            Logs
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="max-w-2xl text-gray-400 text-base md:text-xl font-light leading-relaxed text-balance"
        >
          A high-tech portfolio for a 3D generalist capturing an artistic journey 
          <span className="text-gray-200 block mt-2 font-medium">
            through digital logs and cinematic visuals.
          </span>
        </motion.p>
      </main>
    </div>
  );
}