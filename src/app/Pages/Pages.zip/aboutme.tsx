"use client";
import { motion } from 'framer-motion';
import './Style/aboutme.css';

export default function AboutMe() {
  const tools = ["Unreal Engine", "Blender", "ZBrush", "Maya", "Substance 3D"];

  return (
    /* Removed: bg-[#061016] and overflow-hidden to keep it clean */
    <section id="about" className="relative min-h-screen flex items-center justify-center p-6 md:p-12">
      
      {/* REMOVED: Ambient Background Glows (teal/purple divs) */}

      {/* Main Glass Card */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        viewport={{ once: true }}
        className="relative z-10 w-full max-w-4xl p-8 md:p-14 rounded-4xl premium-liquid-card"
      >
        {/* Pre-headline */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-px bg-[#22d3ee]"></div>
          <span className="text-[#22d3ee] text-xs font-bold tracking-[0.3em] uppercase">
            System.Profile
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight mb-8 tracking-tight">
          3D Generalist &middot; Character Artist &middot; <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-linear-to-r from-[#22d3ee] to-[#a855f7]">
            Professional Tech Magpie
          </span>
        </h1>

        {/* Body Text */}
        <div className="space-y-6 text-gray-300 text-base md:text-lg leading-relaxed font-light pr-0 md:pr-12">
          <p>
            A versatile and imaginative 3D Generalist with a focus on character art and a passion for exploring new tools and technologies. Skilled in sculpting, modeling, texturing, and real-time asset creation for games and interactive media.
          </p>
          <p>
            I thrive in both technical and creative workflows—constantly experimenting, adapting, and pushing boundaries to craft visually compelling and production-ready assets.
          </p>
          
          {/* Blockquote - Wrapped in curly braces to prevent Hydration Mismatch */}
          <div className="my-8 border-l-[3px] border-[#22d3ee]/80 pl-6 py-2">
            <p className="italic text-gray-400 font-normal">
              {"\"Always curious, always learning—I'm the kind of artist who dives deep into both pipelines and pixels.\""}
            </p>
          </div>
        </div>

        {/* Tool Tags */}
        <div className="mt-12 flex flex-wrap gap-4">
          {tools.map((tool, index) => (
            <span 
              key={index}
              className="px-6 py-2 rounded-full border border-white/10 bg-white/5 text-sm font-semibold text-gray-200 tracking-wide hover:bg-white/10 hover:border-[#22d3ee]/50 transition-all duration-300 cursor-default"
            >
              {tool}
            </span>
          ))}
        </div>
      </motion.div>
    </section>
  );
}